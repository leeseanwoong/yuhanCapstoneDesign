﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace form
{
    public delegate void DataGetEventHandler(string data);
    public partial class Form2 : Form
    {
        public static int hour = 0;
        public static int min = 0;
        public static int sec = 0;

        public DataGetEventHandler DataSendEvent;
        public DataGetEventHandler DataSendEvent2;
        public DataGetEventHandler DataSendEvent3;
        public Form2()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e) //정보 form1에 넘겨주기
        {
            DataSendEvent(textBox1.Text);
            DataSendEvent2(textBox5.Text);
            hour = int.Parse(textBox2.Text);
            min = int.Parse(textBox3.Text);
            sec = int.Parse(textBox4.Text);
            DataSendEvent3(hour+":"+min+":"+sec);
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
