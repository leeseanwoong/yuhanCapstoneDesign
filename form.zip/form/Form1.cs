﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace form
{
    public partial class Form1 : MetroFramework.Forms.MetroForm // 상속 클래스 변경 -> 디자인 변경
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {   
            //텍스트 박스에 시험 정보 넣는 부분(DB x)
            textBox1.Text = "시험 정보";

            //데이터 그리드 출력 부분
            dataGridView1.Columns.Add("hakbun", "학번");
            dataGridView1.Columns.Add("name", "이름");
            dataGridView1.Columns.Add("status", "파일 상태");

            //데이터 그리드에 데이터 넣는 부분(아직 DB가 없어서 임시방편)
            dataGridView1.Rows.Add("202007003", "임미현", "진행중");
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) // 시험 준비
        {
            시험 준비에 문제 설정 포함임
            과목 이런거 정하는거
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button4.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button5.Enabled = true;
            button4.Enabled = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button4.Enabled = true;
            button5.Enabled = false;
        }
    }
}
