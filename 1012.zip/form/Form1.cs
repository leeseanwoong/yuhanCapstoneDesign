﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace form
{
    public partial class Form1 : MetroFramework.Forms.MetroForm // 상속 클래스 변경 -> 디자인 변경
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {   
            //라벨에 시험 정보 넣는 부분(DB x)
            label1.Text = "과목명";
            label2.Text = "교수명";
            label3.Text = "시간"; //임시방편

            //데이터 그리드 출력 부분
            dataGridView1.Columns.Add("hakbun", "학번");
            dataGridView1.Columns.Add("name", "이름");
            dataGridView1.Columns.Add("status", "파일 상태");

            //데이터 그리드에 데이터 넣는 부분(아직 DB가 없어서 임시방편)
            dataGridView1.Rows.Add("202007003", "임미현", "진행중");
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) // 시험 설정 ->과목명,시험시간,감독교수 입력
        {
            Form2 f2 = new Form2(this);
            f2.Show();
        }

        private void button3_Click(object sender, EventArgs e) //시험 시작
        {
            //블랙리스트에 해당하는 프로세스 중지, 타이머 시작
            button4.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e) //일시 중지
        {
            //모달 창, 타이머 정지
            button5.Enabled = true;
            button4.Enabled = false;
        }

        private void button5_Click(object sender, EventArgs e) //시험 재개
        {
            //모달 창 제거, 타이머 다시 시작
            button4.Enabled = true;
            button5.Enabled = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            button4.Enabled = false;
            button5.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e) //문제 전송
        {
            //문제 파일 선택, 파일 전송

        }

        private void button8_Click(object sender, EventArgs e) //블랙 리스트
        {
            //금지할 프로세스 선택
        }

        private void button9_Click(object sender, EventArgs e) //화이트 리스트
        {
            //허용할 프로세스 선택
        }

        private void Timer_Tick(object sender, EventArgs e) //타이머 시작 메소드 : timer1.Start();
        {
            //label3.Text = 타이머값;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

    }
}
