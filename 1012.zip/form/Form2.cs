﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace form
{
    public partial class Form2 : Form
    {
        public Form2(Form1 form1)
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) //정보 form1에 넘겨주기
        {
            //Form1.label1.Text = textBox1.Text;  오류가 해결이 안된다
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
